`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [7:0] PI_axi_aw_len;
  reg [1:0] PI_axi_aw_id;
  reg [2:0] PI_axi_ar_prot;
  reg [2:0] PI_axi_ar_size;
  reg [0:0] PI_axi_ar_lock;
  reg [3:0] PI_axi_aw_cache;
  reg [11:0] PI_axi_ar_addr;
  reg [3:0] PI_axi_ar_qos;
  reg [1:0] PI_axi_aw_burst;
  reg [2:0] PI_axi_aw_size;
  reg [0:0] PI_axi_aw_lock;
  reg [31:0] PI_axi_w_data;
  reg [1:0] PI_axi_ar_burst;
  reg [0:0] PI_axi_r_ready;
  reg [1:0] PI_axi_ar_id;
  reg [0:0] PI_axi_aw_valid;
  reg [0:0] PI_axi_b_ready;
  reg [0:0] PI_reset;
  reg [3:0] PI_axi_aw_qos;
  reg [0:0] PI_axi_w_valid;
  reg [3:0] PI_axi_ar_cache;
  reg [3:0] PI_axi_w_strb;
  wire [0:0] PI_clk = clock;
  reg [7:0] PI_axi_ar_len;
  reg [3:0] PI_axi_aw_region;
  reg [0:0] PI_axi_ar_valid;
  reg [2:0] PI_axi_aw_prot;
  reg [3:0] PI_axi_ar_region;
  reg [11:0] PI_axi_aw_addr;
  reg [0:0] PI_axi_w_last;
  NativeAxi4SlaveFactoryFormalMiterOffset64 UUT (
    .axi_aw_len(PI_axi_aw_len),
    .axi_aw_id(PI_axi_aw_id),
    .axi_ar_prot(PI_axi_ar_prot),
    .axi_ar_size(PI_axi_ar_size),
    .axi_ar_lock(PI_axi_ar_lock),
    .axi_aw_cache(PI_axi_aw_cache),
    .axi_ar_addr(PI_axi_ar_addr),
    .axi_ar_qos(PI_axi_ar_qos),
    .axi_aw_burst(PI_axi_aw_burst),
    .axi_aw_size(PI_axi_aw_size),
    .axi_aw_lock(PI_axi_aw_lock),
    .axi_w_data(PI_axi_w_data),
    .axi_ar_burst(PI_axi_ar_burst),
    .axi_r_ready(PI_axi_r_ready),
    .axi_ar_id(PI_axi_ar_id),
    .axi_aw_valid(PI_axi_aw_valid),
    .axi_b_ready(PI_axi_b_ready),
    .reset(PI_reset),
    .axi_aw_qos(PI_axi_aw_qos),
    .axi_w_valid(PI_axi_w_valid),
    .axi_ar_cache(PI_axi_ar_cache),
    .axi_w_strb(PI_axi_w_strb),
    .clk(PI_clk),
    .axi_ar_len(PI_axi_ar_len),
    .axi_aw_region(PI_axi_aw_region),
    .axi_ar_valid(PI_axi_ar_valid),
    .axi_aw_prot(PI_axi_aw_prot),
    .axi_ar_region(PI_axi_ar_region),
    .axi_aw_addr(PI_axi_aw_addr),
    .axi_w_last(PI_axi_w_last)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    UUT.concrete_dut.baseRegister = 32'b00000000000000000000000000000000;
    UUT.concrete_dut.factory_writeRsp_rData_id = 2'b00;
    UUT.concrete_dut.factory_writeRsp_rData_resp = 2'b00;
    UUT.concrete_dut.factory_writeRsp_rValid = 1'b0;
    UUT.concrete_dut.fixedRegister = 32'b00000000000000000000000000000000;
    UUT.concrete_dut.nextRegister = 32'b00000000000000000000000000000000;
    UUT.concrete_dut.readEvent = 1'b0;
    UUT.concrete_dut.unburstify_buffer_beat = 8'b00000000;
    UUT.concrete_dut.unburstify_buffer_beat_1 = 8'b00000000;
    UUT.concrete_dut.unburstify_buffer_len = 8'b00000000;
    UUT.concrete_dut.unburstify_buffer_len_1 = 8'b00000000;
    UUT.concrete_dut.unburstify_buffer_transaction_addr = 12'b000000000000;
    UUT.concrete_dut.unburstify_buffer_transaction_addr_1 = 12'b000000000000;
    UUT.concrete_dut.unburstify_buffer_transaction_burst = 2'b00;
    UUT.concrete_dut.unburstify_buffer_transaction_burst_1 = 2'b00;
    UUT.concrete_dut.unburstify_buffer_transaction_id = 2'b00;
    UUT.concrete_dut.unburstify_buffer_transaction_id_1 = 2'b00;
    UUT.concrete_dut.unburstify_buffer_transaction_size = 3'b000;
    UUT.concrete_dut.unburstify_buffer_transaction_size_1 = 3'b000;
    UUT.concrete_dut.unburstify_buffer_valid = 1'b0;
    UUT.concrete_dut.unburstify_buffer_valid_1 = 1'b0;
    UUT.concrete_dut.unburstify_result_rData_fragment_addr = 12'b000000000000;
    UUT.concrete_dut.unburstify_result_rData_fragment_id = 2'b00;
    UUT.concrete_dut.unburstify_result_rData_last = 1'b0;
    UUT.concrete_dut.unburstify_result_rValid = 1'b0;
    UUT.concrete_dut.writeEvent = 1'b0;
    UUT.morph_dut.baseRegister = 32'b00000000000000000000000000000000;
    UUT.morph_dut.factory_writeRsp_rData_id = 2'b10;
    UUT.morph_dut.factory_writeRsp_rData_resp = 2'b10;
    UUT.morph_dut.factory_writeRsp_rValid = 1'b0;
    UUT.morph_dut.fixedRegister = 32'b10000000000000000000000000000000;
    UUT.morph_dut.nextRegister = 32'b10000000000000000000000000000000;
    UUT.morph_dut.readEvent = 1'b0;
    UUT.morph_dut.unburstify_buffer_beat = 8'b00000000;
    UUT.morph_dut.unburstify_buffer_beat_1 = 8'b00000000;
    UUT.morph_dut.unburstify_buffer_len = 8'b00000000;
    UUT.morph_dut.unburstify_buffer_len_1 = 8'b00000000;
    UUT.morph_dut.unburstify_buffer_transaction_addr = 12'b000000000000;
    UUT.morph_dut.unburstify_buffer_transaction_addr_1 = 12'b000000000000;
    UUT.morph_dut.unburstify_buffer_transaction_burst = 2'b00;
    UUT.morph_dut.unburstify_buffer_transaction_burst_1 = 2'b00;
    UUT.morph_dut.unburstify_buffer_transaction_id = 2'b00;
    UUT.morph_dut.unburstify_buffer_transaction_id_1 = 2'b00;
    UUT.morph_dut.unburstify_buffer_transaction_size = 3'b000;
    UUT.morph_dut.unburstify_buffer_transaction_size_1 = 3'b000;
    UUT.morph_dut.unburstify_buffer_valid = 1'b0;
    UUT.morph_dut.unburstify_buffer_valid_1 = 1'b0;
    UUT.morph_dut.unburstify_result_rData_fragment_addr = 12'b000000000000;
    UUT.morph_dut.unburstify_result_rData_fragment_id = 2'b10;
    UUT.morph_dut.unburstify_result_rData_last = 1'b0;
    UUT.morph_dut.unburstify_result_rValid = 1'b0;
    UUT.morph_dut.writeEvent = 1'b0;

    // state 0
    PI_axi_aw_len = 8'b10000000;
    PI_axi_aw_id = 2'b00;
    PI_axi_ar_prot = 3'b000;
    PI_axi_ar_size = 3'b000;
    PI_axi_ar_lock = 1'b0;
    PI_axi_aw_cache = 4'b0000;
    PI_axi_ar_addr = 12'b000000000000;
    PI_axi_ar_qos = 4'b0000;
    PI_axi_aw_burst = 2'b00;
    PI_axi_aw_size = 3'b000;
    PI_axi_aw_lock = 1'b0;
    PI_axi_w_data = 32'b00000000000000000000000000000000;
    PI_axi_ar_burst = 2'b00;
    PI_axi_r_ready = 1'b0;
    PI_axi_ar_id = 2'b00;
    PI_axi_aw_valid = 1'b0;
    PI_axi_b_ready = 1'b0;
    PI_reset = 1'b1;
    PI_axi_aw_qos = 4'b0000;
    PI_axi_w_valid = 1'b0;
    PI_axi_ar_cache = 4'b0000;
    PI_axi_w_strb = 4'b0000;
    PI_axi_ar_len = 8'b10000000;
    PI_axi_aw_region = 4'b0000;
    PI_axi_ar_valid = 1'b0;
    PI_axi_aw_prot = 3'b000;
    PI_axi_ar_region = 4'b0000;
    PI_axi_aw_addr = 12'b000000000000;
    PI_axi_w_last = 1'b0;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_axi_aw_len <= 8'b00000000;
      PI_axi_aw_id <= 2'b00;
      PI_axi_ar_prot <= 3'b000;
      PI_axi_ar_size <= 3'b000;
      PI_axi_ar_lock <= 1'b0;
      PI_axi_aw_cache <= 4'b0000;
      PI_axi_ar_addr <= 12'b000000000000;
      PI_axi_ar_qos <= 4'b0000;
      PI_axi_aw_burst <= 2'b00;
      PI_axi_aw_size <= 3'b000;
      PI_axi_aw_lock <= 1'b0;
      PI_axi_w_data <= 32'b00000000000000000000000000000000;
      PI_axi_ar_burst <= 2'b00;
      PI_axi_r_ready <= 1'b0;
      PI_axi_ar_id <= 2'b00;
      PI_axi_aw_valid <= 1'b0;
      PI_axi_b_ready <= 1'b0;
      PI_reset <= 1'b0;
      PI_axi_aw_qos <= 4'b0000;
      PI_axi_w_valid <= 1'b0;
      PI_axi_ar_cache <= 4'b0000;
      PI_axi_w_strb <= 4'b0000;
      PI_axi_ar_len <= 8'b00000000;
      PI_axi_aw_region <= 4'b0000;
      PI_axi_ar_valid <= 1'b0;
      PI_axi_aw_prot <= 3'b000;
      PI_axi_ar_region <= 4'b0000;
      PI_axi_aw_addr <= 12'b000000000000;
      PI_axi_w_last <= 1'b0;
    end

    genclock <= cycle < 1;
    cycle <= cycle + 1;
  end
endmodule
