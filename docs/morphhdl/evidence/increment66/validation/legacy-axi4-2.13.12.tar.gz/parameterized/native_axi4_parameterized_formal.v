module NativeAxi4SlaveFactoryParameterizedTop #(
  parameter integer OFFSET_WORD = 16
) (
  input  wire          io_axi_aw_valid,
  output reg           io_axi_aw_ready,
  input  wire [11:0]   io_axi_aw_payload_addr,
  input  wire [1:0]    io_axi_aw_payload_id,
  input  wire [3:0]    io_axi_aw_payload_region,
  input  wire [7:0]    io_axi_aw_payload_len,
  input  wire [2:0]    io_axi_aw_payload_size,
  input  wire [1:0]    io_axi_aw_payload_burst,
  input  wire [0:0]    io_axi_aw_payload_lock,
  input  wire [3:0]    io_axi_aw_payload_cache,
  input  wire [3:0]    io_axi_aw_payload_qos,
  input  wire [2:0]    io_axi_aw_payload_prot,
  input  wire          io_axi_w_valid,
  output wire          io_axi_w_ready,
  input  wire [31:0]   io_axi_w_payload_data,
  input  wire [3:0]    io_axi_w_payload_strb,
  input  wire          io_axi_w_payload_last,
  output wire          io_axi_b_valid,
  input  wire          io_axi_b_ready,
  output wire [1:0]    io_axi_b_payload_id,
  output wire [1:0]    io_axi_b_payload_resp,
  input  wire          io_axi_ar_valid,
  output reg           io_axi_ar_ready,
  input  wire [11:0]   io_axi_ar_payload_addr,
  input  wire [1:0]    io_axi_ar_payload_id,
  input  wire [3:0]    io_axi_ar_payload_region,
  input  wire [7:0]    io_axi_ar_payload_len,
  input  wire [2:0]    io_axi_ar_payload_size,
  input  wire [1:0]    io_axi_ar_payload_burst,
  input  wire [0:0]    io_axi_ar_payload_lock,
  input  wire [3:0]    io_axi_ar_payload_cache,
  input  wire [3:0]    io_axi_ar_payload_qos,
  input  wire [2:0]    io_axi_ar_payload_prot,
  output wire          io_axi_r_valid,
  input  wire          io_axi_r_ready,
  output wire [31:0]   io_axi_r_payload_data,
  output wire [1:0]    io_axi_r_payload_id,
  output wire [1:0]    io_axi_r_payload_resp,
  output wire          io_axi_r_payload_last,
  output wire [31:0]   io_observedBase,
  output wire [31:0]   io_observedNext,
  output wire [31:0]   io_observedFixed,
  output wire          io_observedReadEvent,
  output wire          io_observedWriteEvent,
  input  wire          clk,
  input  wire          reset
);
  localparam integer EVENT_OFFSET = ((OFFSET_WORD * 4) + 8);

  wire       [1:0]    _zz_Axi4Incr_alignMask;
  wire       [2:0]    _zz_Axi4Incr_wrapCase_2;
  wire       [2:0]    _zz_Axi4Incr_wrapCase_3;
  reg        [11:0]   _zz__zz_Axi4Incr_result;
  wire       [1:0]    _zz_Axi4Incr_alignMask_1;
  wire       [2:0]    _zz_Axi4Incr_wrapCase_1_1;
  wire       [2:0]    _zz_Axi4Incr_wrapCase_1_2;
  reg        [11:0]   _zz__zz_Axi4Incr_result_3;
  reg        [31:0]   baseRegister;
  reg        [31:0]   nextRegister;
  reg        [31:0]   fixedRegister;
  reg                 readEvent;
  reg                 writeEvent;
  wire                factory_readErrorFlag;
  wire                factory_writeErrorFlag;
  wire                factory_readHaltRequest;
  wire                factory_writeHaltRequest;
  reg                 unburstify_result_valid;
  wire                unburstify_result_ready;
  reg                 unburstify_result_payload_last;
  reg        [11:0]   unburstify_result_payload_fragment_addr;
  reg        [1:0]    unburstify_result_payload_fragment_id;
  reg        [3:0]    unburstify_result_payload_fragment_region;
  reg        [2:0]    unburstify_result_payload_fragment_size;
  reg        [1:0]    unburstify_result_payload_fragment_burst;
  reg        [0:0]    unburstify_result_payload_fragment_lock;
  reg        [3:0]    unburstify_result_payload_fragment_cache;
  reg        [3:0]    unburstify_result_payload_fragment_qos;
  reg        [2:0]    unburstify_result_payload_fragment_prot;
  wire                unburstify_doResult;
  reg                 unburstify_buffer_valid;
  reg        [7:0]    unburstify_buffer_len;
  reg        [7:0]    unburstify_buffer_beat;
  reg        [11:0]   unburstify_buffer_transaction_addr;
  reg        [1:0]    unburstify_buffer_transaction_id;
  reg        [3:0]    unburstify_buffer_transaction_region;
  reg        [2:0]    unburstify_buffer_transaction_size;
  reg        [1:0]    unburstify_buffer_transaction_burst;
  reg        [0:0]    unburstify_buffer_transaction_lock;
  reg        [3:0]    unburstify_buffer_transaction_cache;
  reg        [3:0]    unburstify_buffer_transaction_qos;
  reg        [2:0]    unburstify_buffer_transaction_prot;
  wire                unburstify_buffer_last;
  wire       [1:0]    Axi4Incr_validSize;
  reg        [11:0]   Axi4Incr_result;
  wire       [2:0]    Axi4Incr_sizeValue;
  wire       [11:0]   Axi4Incr_alignMask;
  wire       [11:0]   Axi4Incr_base;
  wire       [11:0]   Axi4Incr_baseIncr;
  reg        [1:0]    _zz_Axi4Incr_wrapCase;
  wire       [2:0]    Axi4Incr_wrapCase;
  wire       [11:0]   _zz_Axi4Incr_result;
  wire       [11:0]   _zz_Axi4Incr_result_1;
  wire       [11:0]   _zz_Axi4Incr_result_2;
  reg                 factory_writeJoinEvent_ready;
  wire                factory_writeOccur;
  reg                 factory_writeRsp_valid;
  reg                 factory_writeRsp_ready;
  wire       [1:0]    factory_writeRsp_payload_id;
  reg        [1:0]    factory_writeRsp_payload_resp;
  wire                factory_writeRsp_stage_ready;
  reg                 factory_writeRsp_rValid;
  reg        [1:0]    factory_writeRsp_rData_id;
  reg        [1:0]    factory_writeRsp_rData_resp;
  reg                 unburstify_result_valid_1;
  reg                 unburstify_result_ready_1;
  reg                 unburstify_result_payload_last_1;
  reg        [11:0]   unburstify_result_payload_fragment_addr_1;
  reg        [1:0]    unburstify_result_payload_fragment_id_1;
  reg        [3:0]    unburstify_result_payload_fragment_region_1;
  reg        [2:0]    unburstify_result_payload_fragment_size_1;
  reg        [1:0]    unburstify_result_payload_fragment_burst_1;
  reg        [0:0]    unburstify_result_payload_fragment_lock_1;
  reg        [3:0]    unburstify_result_payload_fragment_cache_1;
  reg        [3:0]    unburstify_result_payload_fragment_qos_1;
  reg        [2:0]    unburstify_result_payload_fragment_prot_1;
  wire                unburstify_doResult_1;
  reg                 unburstify_buffer_valid_1;
  reg        [7:0]    unburstify_buffer_len_1;
  reg        [7:0]    unburstify_buffer_beat_1;
  reg        [11:0]   unburstify_buffer_transaction_addr_1;
  reg        [1:0]    unburstify_buffer_transaction_id_1;
  reg        [3:0]    unburstify_buffer_transaction_region_1;
  reg        [2:0]    unburstify_buffer_transaction_size_1;
  reg        [1:0]    unburstify_buffer_transaction_burst_1;
  reg        [0:0]    unburstify_buffer_transaction_lock_1;
  reg        [3:0]    unburstify_buffer_transaction_cache_1;
  reg        [3:0]    unburstify_buffer_transaction_qos_1;
  reg        [2:0]    unburstify_buffer_transaction_prot_1;
  wire                unburstify_buffer_last_1;
  wire       [1:0]    Axi4Incr_validSize_1;
  reg        [11:0]   Axi4Incr_result_1;
  wire       [2:0]    Axi4Incr_sizeValue_1;
  wire       [11:0]   Axi4Incr_alignMask_1;
  wire       [11:0]   Axi4Incr_base_1;
  wire       [11:0]   Axi4Incr_baseIncr_1;
  reg        [1:0]    _zz_Axi4Incr_wrapCase_1;
  wire       [2:0]    Axi4Incr_wrapCase_1;
  wire       [11:0]   _zz_Axi4Incr_result_3;
  wire       [11:0]   _zz_Axi4Incr_result_4;
  wire       [11:0]   _zz_Axi4Incr_result_5;
  wire                factory_readDataStage_ready;
  reg                 unburstify_result_rValid;
  reg                 unburstify_result_rData_last;
  reg        [11:0]   unburstify_result_rData_fragment_addr;
  reg        [1:0]    unburstify_result_rData_fragment_id;
  reg        [3:0]    unburstify_result_rData_fragment_region;
  reg        [2:0]    unburstify_result_rData_fragment_size;
  reg        [1:0]    unburstify_result_rData_fragment_burst;
  reg        [0:0]    unburstify_result_rData_fragment_lock;
  reg        [3:0]    unburstify_result_rData_fragment_cache;
  reg        [3:0]    unburstify_result_rData_fragment_qos;
  reg        [2:0]    unburstify_result_rData_fragment_prot;
  reg        [31:0]   factory_readRsp_data;
  reg        [1:0]    factory_readRsp_resp;
  wire                factory_readOccur;
  wire       [11:0]   factory_readAddressMasked;
  wire       [11:0]   factory_writeAddressMasked;
  wire                when_BusSlaveFactory_l1299;
  wire                when_BusSlaveFactory_l1299_1;
  wire                when_BusSlaveFactory_l1299_2;
  wire                when_BusSlaveFactory_l1299_3;
  wire       [11:0]   morphhdl_typed_value_1;
  wire                when_Axi4SlaveFactory_l94;
  wire                when_BusSlaveFactory_l1299_4;
  wire                when_BusSlaveFactory_l1299_5;
  wire                when_BusSlaveFactory_l1299_6;
  wire                when_BusSlaveFactory_l1299_7;
  wire       [11:0]   morphhdl_typed_value_2;
  wire                when_Axi4SlaveFactory_l94_1;
  wire                when_BusSlaveFactory_l1299_8;
  wire                when_BusSlaveFactory_l1299_9;
  wire                when_BusSlaveFactory_l1299_10;
  wire                when_BusSlaveFactory_l1299_11;
  wire       [11:0]   morphhdl_typed_value_3;
  wire                when_Axi4SlaveFactory_l94_2;
  wire       [11:0]   morphhdl_typed_value_4;
  wire       [11:0]   morphhdl_typed_value_5;
  wire       [11:0]   morphhdl_typed_value_6;

  assign _zz_Axi4Incr_alignMask = {(2'b01 < Axi4Incr_validSize),(2'b00 < Axi4Incr_validSize)};
  assign _zz_Axi4Incr_wrapCase_2 = {1'd0, Axi4Incr_validSize};
  assign _zz_Axi4Incr_wrapCase_3 = {1'd0, _zz_Axi4Incr_wrapCase};
  assign _zz_Axi4Incr_alignMask_1 = {(2'b01 < Axi4Incr_validSize_1),(2'b00 < Axi4Incr_validSize_1)};
  assign _zz_Axi4Incr_wrapCase_1_1 = {1'd0, Axi4Incr_validSize_1};
  assign _zz_Axi4Incr_wrapCase_1_2 = {1'd0, _zz_Axi4Incr_wrapCase_1};
  always @(*) begin
    case(Axi4Incr_wrapCase)
      3'b000 : _zz__zz_Axi4Incr_result = {Axi4Incr_base[11 : 1],Axi4Incr_baseIncr[0 : 0]};
      3'b001 : _zz__zz_Axi4Incr_result = {Axi4Incr_base[11 : 2],Axi4Incr_baseIncr[1 : 0]};
      3'b010 : _zz__zz_Axi4Incr_result = {Axi4Incr_base[11 : 3],Axi4Incr_baseIncr[2 : 0]};
      3'b011 : _zz__zz_Axi4Incr_result = {Axi4Incr_base[11 : 4],Axi4Incr_baseIncr[3 : 0]};
      3'b100 : _zz__zz_Axi4Incr_result = {Axi4Incr_base[11 : 5],Axi4Incr_baseIncr[4 : 0]};
      default : _zz__zz_Axi4Incr_result = {Axi4Incr_base[11 : 6],Axi4Incr_baseIncr[5 : 0]};
    endcase
  end

  always @(*) begin
    case(Axi4Incr_wrapCase_1)
      3'b000 : _zz__zz_Axi4Incr_result_3 = {Axi4Incr_base_1[11 : 1],Axi4Incr_baseIncr_1[0 : 0]};
      3'b001 : _zz__zz_Axi4Incr_result_3 = {Axi4Incr_base_1[11 : 2],Axi4Incr_baseIncr_1[1 : 0]};
      3'b010 : _zz__zz_Axi4Incr_result_3 = {Axi4Incr_base_1[11 : 3],Axi4Incr_baseIncr_1[2 : 0]};
      3'b011 : _zz__zz_Axi4Incr_result_3 = {Axi4Incr_base_1[11 : 4],Axi4Incr_baseIncr_1[3 : 0]};
      3'b100 : _zz__zz_Axi4Incr_result_3 = {Axi4Incr_base_1[11 : 5],Axi4Incr_baseIncr_1[4 : 0]};
      default : _zz__zz_Axi4Incr_result_3 = {Axi4Incr_base_1[11 : 6],Axi4Incr_baseIncr_1[5 : 0]};
    endcase
  end

  assign io_observedBase = baseRegister;
  assign io_observedNext = nextRegister;
  assign io_observedFixed = fixedRegister;
  assign io_observedReadEvent = readEvent;
  assign io_observedWriteEvent = writeEvent;
  assign factory_readErrorFlag = 1'b0;
  assign factory_writeErrorFlag = 1'b0;
  assign factory_readHaltRequest = 1'b0;
  assign factory_writeHaltRequest = 1'b0;
  assign unburstify_buffer_last = (unburstify_buffer_beat == 8'h01);
  assign Axi4Incr_validSize = unburstify_buffer_transaction_size[1 : 0];
  assign Axi4Incr_sizeValue = {(2'b10 == Axi4Incr_validSize),{(2'b01 == Axi4Incr_validSize),(2'b00 == Axi4Incr_validSize)}};
  assign Axi4Incr_alignMask = {10'd0, _zz_Axi4Incr_alignMask};
  assign Axi4Incr_base = (unburstify_buffer_transaction_addr[11 : 0] & (~ Axi4Incr_alignMask));
  assign Axi4Incr_baseIncr = (Axi4Incr_base + {9'd0, Axi4Incr_sizeValue});
  always @(*) begin
    casez(unburstify_buffer_len)
      8'b????1??? : begin
        _zz_Axi4Incr_wrapCase = 2'b11;
      end
      8'b????01?? : begin
        _zz_Axi4Incr_wrapCase = 2'b10;
      end
      8'b????001? : begin
        _zz_Axi4Incr_wrapCase = 2'b01;
      end
      default : begin
        _zz_Axi4Incr_wrapCase = 2'b00;
      end
    endcase
  end

  assign Axi4Incr_wrapCase = (_zz_Axi4Incr_wrapCase_2 + _zz_Axi4Incr_wrapCase_3);
  always @(*) begin
    case(unburstify_buffer_transaction_burst)
      2'b00 : begin
        Axi4Incr_result = unburstify_buffer_transaction_addr;
      end
      2'b10 : begin
        Axi4Incr_result = _zz_Axi4Incr_result_1;
      end
      default : begin
        Axi4Incr_result = _zz_Axi4Incr_result_2;
      end
    endcase
  end

  assign _zz_Axi4Incr_result = _zz__zz_Axi4Incr_result;
  assign _zz_Axi4Incr_result_1 = _zz_Axi4Incr_result;
  assign _zz_Axi4Incr_result_2 = Axi4Incr_baseIncr;
  always @(*) begin
    io_axi_aw_ready = 1'b0;
    if(!unburstify_buffer_valid) begin
      io_axi_aw_ready = unburstify_result_ready;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid) begin
      unburstify_result_valid = 1'b1;
    end else begin
      unburstify_result_valid = io_axi_aw_valid;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid) begin
      unburstify_result_payload_last = unburstify_buffer_last;
    end else begin
      unburstify_result_payload_last = 1'b1;
      if((io_axi_aw_payload_len != 8'h0)) begin
        unburstify_result_payload_last = 1'b0;
      end
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid) begin
      unburstify_result_payload_fragment_id = unburstify_buffer_transaction_id;
    end else begin
      unburstify_result_payload_fragment_id = io_axi_aw_payload_id;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid) begin
      unburstify_result_payload_fragment_region = unburstify_buffer_transaction_region;
    end else begin
      unburstify_result_payload_fragment_region = io_axi_aw_payload_region;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid) begin
      unburstify_result_payload_fragment_size = unburstify_buffer_transaction_size;
    end else begin
      unburstify_result_payload_fragment_size = io_axi_aw_payload_size;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid) begin
      unburstify_result_payload_fragment_burst = unburstify_buffer_transaction_burst;
    end else begin
      unburstify_result_payload_fragment_burst = io_axi_aw_payload_burst;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid) begin
      unburstify_result_payload_fragment_lock = unburstify_buffer_transaction_lock;
    end else begin
      unburstify_result_payload_fragment_lock = io_axi_aw_payload_lock;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid) begin
      unburstify_result_payload_fragment_cache = unburstify_buffer_transaction_cache;
    end else begin
      unburstify_result_payload_fragment_cache = io_axi_aw_payload_cache;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid) begin
      unburstify_result_payload_fragment_qos = unburstify_buffer_transaction_qos;
    end else begin
      unburstify_result_payload_fragment_qos = io_axi_aw_payload_qos;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid) begin
      unburstify_result_payload_fragment_prot = unburstify_buffer_transaction_prot;
    end else begin
      unburstify_result_payload_fragment_prot = io_axi_aw_payload_prot;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid) begin
      unburstify_result_payload_fragment_addr = Axi4Incr_result;
    end else begin
      unburstify_result_payload_fragment_addr = io_axi_aw_payload_addr;
    end
  end

  assign factory_writeOccur = ((unburstify_result_valid && io_axi_w_valid) && factory_writeJoinEvent_ready);
  assign unburstify_result_ready = factory_writeOccur;
  assign io_axi_w_ready = factory_writeOccur;
  always @(*) begin
    factory_writeRsp_ready = factory_writeRsp_stage_ready;
    if((! factory_writeRsp_rValid)) begin
      factory_writeRsp_ready = 1'b1;
    end
  end

  assign io_axi_b_valid = factory_writeRsp_rValid;
  assign factory_writeRsp_stage_ready = io_axi_b_ready;
  assign io_axi_b_payload_id = factory_writeRsp_rData_id;
  assign io_axi_b_payload_resp = factory_writeRsp_rData_resp;
  always @(*) begin
    if(io_axi_w_payload_last) begin
      factory_writeJoinEvent_ready = (factory_writeRsp_ready && (! factory_writeHaltRequest));
    end else begin
      factory_writeJoinEvent_ready = (! factory_writeHaltRequest);
    end
  end

  always @(*) begin
    if(io_axi_w_payload_last) begin
      factory_writeRsp_valid = factory_writeOccur;
    end else begin
      factory_writeRsp_valid = 1'b0;
    end
  end

  assign unburstify_buffer_last_1 = (unburstify_buffer_beat_1 == 8'h01);
  assign Axi4Incr_validSize_1 = unburstify_buffer_transaction_size_1[1 : 0];
  assign Axi4Incr_sizeValue_1 = {(2'b10 == Axi4Incr_validSize_1),{(2'b01 == Axi4Incr_validSize_1),(2'b00 == Axi4Incr_validSize_1)}};
  assign Axi4Incr_alignMask_1 = {10'd0, _zz_Axi4Incr_alignMask_1};
  assign Axi4Incr_base_1 = (unburstify_buffer_transaction_addr_1[11 : 0] & (~ Axi4Incr_alignMask_1));
  assign Axi4Incr_baseIncr_1 = (Axi4Incr_base_1 + {9'd0, Axi4Incr_sizeValue_1});
  always @(*) begin
    casez(unburstify_buffer_len_1)
      8'b????1??? : begin
        _zz_Axi4Incr_wrapCase_1 = 2'b11;
      end
      8'b????01?? : begin
        _zz_Axi4Incr_wrapCase_1 = 2'b10;
      end
      8'b????001? : begin
        _zz_Axi4Incr_wrapCase_1 = 2'b01;
      end
      default : begin
        _zz_Axi4Incr_wrapCase_1 = 2'b00;
      end
    endcase
  end

  assign Axi4Incr_wrapCase_1 = (_zz_Axi4Incr_wrapCase_1_1 + _zz_Axi4Incr_wrapCase_1_2);
  always @(*) begin
    case(unburstify_buffer_transaction_burst_1)
      2'b00 : begin
        Axi4Incr_result_1 = unburstify_buffer_transaction_addr_1;
      end
      2'b10 : begin
        Axi4Incr_result_1 = _zz_Axi4Incr_result_4;
      end
      default : begin
        Axi4Incr_result_1 = _zz_Axi4Incr_result_5;
      end
    endcase
  end

  assign _zz_Axi4Incr_result_3 = _zz__zz_Axi4Incr_result_3;
  assign _zz_Axi4Incr_result_4 = _zz_Axi4Incr_result_3;
  assign _zz_Axi4Incr_result_5 = Axi4Incr_baseIncr_1;
  always @(*) begin
    io_axi_ar_ready = 1'b0;
    if(!unburstify_buffer_valid_1) begin
      io_axi_ar_ready = unburstify_result_ready_1;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid_1) begin
      unburstify_result_valid_1 = 1'b1;
    end else begin
      unburstify_result_valid_1 = io_axi_ar_valid;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid_1) begin
      unburstify_result_payload_last_1 = unburstify_buffer_last_1;
    end else begin
      unburstify_result_payload_last_1 = 1'b1;
      if((io_axi_ar_payload_len != 8'h0)) begin
        unburstify_result_payload_last_1 = 1'b0;
      end
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid_1) begin
      unburstify_result_payload_fragment_id_1 = unburstify_buffer_transaction_id_1;
    end else begin
      unburstify_result_payload_fragment_id_1 = io_axi_ar_payload_id;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid_1) begin
      unburstify_result_payload_fragment_region_1 = unburstify_buffer_transaction_region_1;
    end else begin
      unburstify_result_payload_fragment_region_1 = io_axi_ar_payload_region;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid_1) begin
      unburstify_result_payload_fragment_size_1 = unburstify_buffer_transaction_size_1;
    end else begin
      unburstify_result_payload_fragment_size_1 = io_axi_ar_payload_size;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid_1) begin
      unburstify_result_payload_fragment_burst_1 = unburstify_buffer_transaction_burst_1;
    end else begin
      unburstify_result_payload_fragment_burst_1 = io_axi_ar_payload_burst;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid_1) begin
      unburstify_result_payload_fragment_lock_1 = unburstify_buffer_transaction_lock_1;
    end else begin
      unburstify_result_payload_fragment_lock_1 = io_axi_ar_payload_lock;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid_1) begin
      unburstify_result_payload_fragment_cache_1 = unburstify_buffer_transaction_cache_1;
    end else begin
      unburstify_result_payload_fragment_cache_1 = io_axi_ar_payload_cache;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid_1) begin
      unburstify_result_payload_fragment_qos_1 = unburstify_buffer_transaction_qos_1;
    end else begin
      unburstify_result_payload_fragment_qos_1 = io_axi_ar_payload_qos;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid_1) begin
      unburstify_result_payload_fragment_prot_1 = unburstify_buffer_transaction_prot_1;
    end else begin
      unburstify_result_payload_fragment_prot_1 = io_axi_ar_payload_prot;
    end
  end

  always @(*) begin
    if(unburstify_buffer_valid_1) begin
      unburstify_result_payload_fragment_addr_1 = Axi4Incr_result_1;
    end else begin
      unburstify_result_payload_fragment_addr_1 = io_axi_ar_payload_addr;
    end
  end

  always @(*) begin
    unburstify_result_ready_1 = factory_readDataStage_ready;
    if((! unburstify_result_rValid)) begin
      unburstify_result_ready_1 = 1'b1;
    end
  end

  assign factory_readDataStage_ready = (io_axi_r_ready && (! factory_readHaltRequest));
  assign io_axi_r_valid = (unburstify_result_rValid && (! factory_readHaltRequest));
  assign io_axi_r_payload_data = factory_readRsp_data;
  assign io_axi_r_payload_id = unburstify_result_rData_fragment_id;
  assign io_axi_r_payload_resp = factory_readRsp_resp;
  assign io_axi_r_payload_last = unburstify_result_rData_last;
  assign factory_writeRsp_payload_id = unburstify_result_payload_fragment_id;
  always @(*) begin
    if(factory_writeErrorFlag) begin
      factory_writeRsp_payload_resp = 2'b10;
    end else begin
      factory_writeRsp_payload_resp = 2'b00;
    end
  end

  always @(*) begin
    if(factory_readErrorFlag) begin
      factory_readRsp_resp = 2'b10;
    end else begin
      factory_readRsp_resp = 2'b00;
    end
  end

  always @(*) begin
    factory_readRsp_data = 32'h0;
    case(factory_readAddressMasked)
      12'h080 : begin
        factory_readRsp_data[31 : 0] = fixedRegister;
      end
      default : begin
      end
    endcase
    if((factory_readAddressMasked == morphhdl_typed_value_4)) begin
      factory_readRsp_data[31 : 0] = baseRegister;
    end
    if((factory_readAddressMasked == morphhdl_typed_value_5)) begin
      factory_readRsp_data[31 : 0] = nextRegister;
    end
  end

  assign factory_readOccur = (io_axi_r_valid && io_axi_r_ready);
  assign factory_readAddressMasked = (unburstify_result_rData_fragment_addr & (~ 12'h003));
  assign factory_writeAddressMasked = (unburstify_result_payload_fragment_addr & (~ 12'h003));
  assign when_BusSlaveFactory_l1299 = io_axi_w_payload_strb[0];
  assign when_BusSlaveFactory_l1299_1 = io_axi_w_payload_strb[1];
  assign when_BusSlaveFactory_l1299_2 = io_axi_w_payload_strb[2];
  assign when_BusSlaveFactory_l1299_3 = io_axi_w_payload_strb[3];
  assign morphhdl_typed_value_1 = ((OFFSET_WORD * 4));
  assign when_Axi4SlaveFactory_l94 = (factory_writeAddressMasked == morphhdl_typed_value_1);
  assign when_BusSlaveFactory_l1299_4 = io_axi_w_payload_strb[0];
  assign when_BusSlaveFactory_l1299_5 = io_axi_w_payload_strb[1];
  assign when_BusSlaveFactory_l1299_6 = io_axi_w_payload_strb[2];
  assign when_BusSlaveFactory_l1299_7 = io_axi_w_payload_strb[3];
  assign morphhdl_typed_value_2 = (((OFFSET_WORD * 4) + 4));
  assign when_Axi4SlaveFactory_l94_1 = (factory_writeAddressMasked == morphhdl_typed_value_2);
  assign when_BusSlaveFactory_l1299_8 = io_axi_w_payload_strb[0];
  assign when_BusSlaveFactory_l1299_9 = io_axi_w_payload_strb[1];
  assign when_BusSlaveFactory_l1299_10 = io_axi_w_payload_strb[2];
  assign when_BusSlaveFactory_l1299_11 = io_axi_w_payload_strb[3];
  assign morphhdl_typed_value_3 = (EVENT_OFFSET);
  assign when_Axi4SlaveFactory_l94_2 = (factory_writeAddressMasked == morphhdl_typed_value_3);
  assign morphhdl_typed_value_4 = ((OFFSET_WORD * 4));
  assign morphhdl_typed_value_5 = (((OFFSET_WORD * 4) + 4));
  assign morphhdl_typed_value_6 = (EVENT_OFFSET);
  always @(posedge clk) begin
    if(reset) begin
      baseRegister <= 32'h0;
      nextRegister <= 32'h0;
      fixedRegister <= 32'h0;
      readEvent <= 1'b0;
      writeEvent <= 1'b0;
      unburstify_buffer_valid <= 1'b0;
      factory_writeRsp_rValid <= 1'b0;
      unburstify_buffer_valid_1 <= 1'b0;
      unburstify_result_rValid <= 1'b0;
    end else begin
      if(unburstify_result_ready) begin
        if(unburstify_buffer_last) begin
          unburstify_buffer_valid <= 1'b0;
        end
      end
      if(!unburstify_buffer_valid) begin
        if((io_axi_aw_payload_len != 8'h0)) begin
          if(unburstify_result_ready) begin
            unburstify_buffer_valid <= io_axi_aw_valid;
          end
        end
      end
      if(factory_writeRsp_ready) begin
        factory_writeRsp_rValid <= factory_writeRsp_valid;
      end
      if(unburstify_result_ready_1) begin
        if(unburstify_buffer_last_1) begin
          unburstify_buffer_valid_1 <= 1'b0;
        end
      end
      if(!unburstify_buffer_valid_1) begin
        if((io_axi_ar_payload_len != 8'h0)) begin
          if(unburstify_result_ready_1) begin
            unburstify_buffer_valid_1 <= io_axi_ar_valid;
          end
        end
      end
      if(unburstify_result_ready_1) begin
        unburstify_result_rValid <= unburstify_result_valid_1;
      end
      case(factory_writeAddressMasked)
        12'h080 : begin
          if(factory_writeOccur) begin
            if(when_BusSlaveFactory_l1299) begin
              fixedRegister[7 : 0] <= io_axi_w_payload_data[7 : 0];
            end
            if(when_BusSlaveFactory_l1299_1) begin
              fixedRegister[15 : 8] <= io_axi_w_payload_data[15 : 8];
            end
            if(when_BusSlaveFactory_l1299_2) begin
              fixedRegister[23 : 16] <= io_axi_w_payload_data[23 : 16];
            end
            if(when_BusSlaveFactory_l1299_3) begin
              fixedRegister[31 : 24] <= io_axi_w_payload_data[31 : 24];
            end
          end
        end
        default : begin
        end
      endcase
      if(when_Axi4SlaveFactory_l94) begin
        if(factory_writeOccur) begin
          if(when_BusSlaveFactory_l1299_4) begin
            baseRegister[7 : 0] <= io_axi_w_payload_data[7 : 0];
          end
          if(when_BusSlaveFactory_l1299_5) begin
            baseRegister[15 : 8] <= io_axi_w_payload_data[15 : 8];
          end
          if(when_BusSlaveFactory_l1299_6) begin
            baseRegister[23 : 16] <= io_axi_w_payload_data[23 : 16];
          end
          if(when_BusSlaveFactory_l1299_7) begin
            baseRegister[31 : 24] <= io_axi_w_payload_data[31 : 24];
          end
        end
      end
      if(when_Axi4SlaveFactory_l94_1) begin
        if(factory_writeOccur) begin
          if(when_BusSlaveFactory_l1299_8) begin
            nextRegister[7 : 0] <= io_axi_w_payload_data[7 : 0];
          end
          if(when_BusSlaveFactory_l1299_9) begin
            nextRegister[15 : 8] <= io_axi_w_payload_data[15 : 8];
          end
          if(when_BusSlaveFactory_l1299_10) begin
            nextRegister[23 : 16] <= io_axi_w_payload_data[23 : 16];
          end
          if(when_BusSlaveFactory_l1299_11) begin
            nextRegister[31 : 24] <= io_axi_w_payload_data[31 : 24];
          end
        end
      end
      if(when_Axi4SlaveFactory_l94_2) begin
        if(factory_writeOccur) begin
          writeEvent <= 1'b1;
        end
      end
      if((factory_readAddressMasked == morphhdl_typed_value_6)) begin
        if(factory_readOccur) begin
          readEvent <= 1'b1;
        end
      end
    end
  end

  always @(posedge clk) begin
    if(unburstify_result_ready) begin
      unburstify_buffer_beat <= (unburstify_buffer_beat - 8'h01);
      unburstify_buffer_transaction_addr[11 : 0] <= Axi4Incr_result[11 : 0];
    end
    if(!unburstify_buffer_valid) begin
      if((io_axi_aw_payload_len != 8'h0)) begin
        if(unburstify_result_ready) begin
          unburstify_buffer_transaction_addr <= io_axi_aw_payload_addr;
          unburstify_buffer_transaction_id <= io_axi_aw_payload_id;
          unburstify_buffer_transaction_region <= io_axi_aw_payload_region;
          unburstify_buffer_transaction_size <= io_axi_aw_payload_size;
          unburstify_buffer_transaction_burst <= io_axi_aw_payload_burst;
          unburstify_buffer_transaction_lock <= io_axi_aw_payload_lock;
          unburstify_buffer_transaction_cache <= io_axi_aw_payload_cache;
          unburstify_buffer_transaction_qos <= io_axi_aw_payload_qos;
          unburstify_buffer_transaction_prot <= io_axi_aw_payload_prot;
          unburstify_buffer_beat <= io_axi_aw_payload_len;
          unburstify_buffer_len <= io_axi_aw_payload_len;
        end
      end
    end
    if(factory_writeRsp_ready) begin
      factory_writeRsp_rData_id <= factory_writeRsp_payload_id;
      factory_writeRsp_rData_resp <= factory_writeRsp_payload_resp;
    end
    if(unburstify_result_ready_1) begin
      unburstify_buffer_beat_1 <= (unburstify_buffer_beat_1 - 8'h01);
      unburstify_buffer_transaction_addr_1[11 : 0] <= Axi4Incr_result_1[11 : 0];
    end
    if(!unburstify_buffer_valid_1) begin
      if((io_axi_ar_payload_len != 8'h0)) begin
        if(unburstify_result_ready_1) begin
          unburstify_buffer_transaction_addr_1 <= io_axi_ar_payload_addr;
          unburstify_buffer_transaction_id_1 <= io_axi_ar_payload_id;
          unburstify_buffer_transaction_region_1 <= io_axi_ar_payload_region;
          unburstify_buffer_transaction_size_1 <= io_axi_ar_payload_size;
          unburstify_buffer_transaction_burst_1 <= io_axi_ar_payload_burst;
          unburstify_buffer_transaction_lock_1 <= io_axi_ar_payload_lock;
          unburstify_buffer_transaction_cache_1 <= io_axi_ar_payload_cache;
          unburstify_buffer_transaction_qos_1 <= io_axi_ar_payload_qos;
          unburstify_buffer_transaction_prot_1 <= io_axi_ar_payload_prot;
          unburstify_buffer_beat_1 <= io_axi_ar_payload_len;
          unburstify_buffer_len_1 <= io_axi_ar_payload_len;
        end
      end
    end
    if(unburstify_result_ready_1) begin
      unburstify_result_rData_last <= unburstify_result_payload_last_1;
      unburstify_result_rData_fragment_addr <= unburstify_result_payload_fragment_addr_1;
      unburstify_result_rData_fragment_id <= unburstify_result_payload_fragment_id_1;
      unburstify_result_rData_fragment_region <= unburstify_result_payload_fragment_region_1;
      unburstify_result_rData_fragment_size <= unburstify_result_payload_fragment_size_1;
      unburstify_result_rData_fragment_burst <= unburstify_result_payload_fragment_burst_1;
      unburstify_result_rData_fragment_lock <= unburstify_result_payload_fragment_lock_1;
      unburstify_result_rData_fragment_cache <= unburstify_result_payload_fragment_cache_1;
      unburstify_result_rData_fragment_qos <= unburstify_result_payload_fragment_qos_1;
      unburstify_result_rData_fragment_prot <= unburstify_result_payload_fragment_prot_1;
    end
  end


endmodule
