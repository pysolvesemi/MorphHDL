module NativeAxi4SlaveFactoryFormalMiterOffset112 (
  input wire clk,
  input wire reset,
  input wire axi_aw_valid,
  input wire [11:0] axi_aw_addr,
  input wire [1:0] axi_aw_id,
  input wire [3:0] axi_aw_region,
  input wire [7:0] axi_aw_len,
  input wire [2:0] axi_aw_size,
  input wire [1:0] axi_aw_burst,
  input wire axi_aw_lock,
  input wire [3:0] axi_aw_cache,
  input wire [3:0] axi_aw_qos,
  input wire [2:0] axi_aw_prot,
  input wire axi_w_valid,
  input wire [31:0] axi_w_data,
  input wire [3:0] axi_w_strb,
  input wire axi_w_last,
  input wire axi_b_ready,
  input wire axi_ar_valid,
  input wire [11:0] axi_ar_addr,
  input wire [1:0] axi_ar_id,
  input wire [3:0] axi_ar_region,
  input wire [7:0] axi_ar_len,
  input wire [2:0] axi_ar_size,
  input wire [1:0] axi_ar_burst,
  input wire axi_ar_lock,
  input wire [3:0] axi_ar_cache,
  input wire [3:0] axi_ar_qos,
  input wire [2:0] axi_ar_prot,
  input wire axi_r_ready
);
  wire concrete_aw_ready;
  wire concrete_w_ready;
  wire concrete_b_valid;
  wire [1:0] concrete_b_id;
  wire [1:0] concrete_b_resp;
  wire concrete_ar_ready;
  wire concrete_r_valid;
  wire [31:0] concrete_r_data;
  wire [1:0] concrete_r_id;
  wire [1:0] concrete_r_resp;
  wire concrete_r_last;
  wire [31:0] concrete_observed_base;
  wire [31:0] concrete_observed_next;
  wire [31:0] concrete_observed_fixed;
  wire concrete_observed_read_event;
  wire concrete_observed_write_event;

  wire morph_aw_ready;
  wire morph_w_ready;
  wire morph_b_valid;
  wire [1:0] morph_b_id;
  wire [1:0] morph_b_resp;
  wire morph_ar_ready;
  wire morph_r_valid;
  wire [31:0] morph_r_data;
  wire [1:0] morph_r_id;
  wire [1:0] morph_r_resp;
  wire morph_r_last;
  wire [31:0] morph_observed_base;
  wire [31:0] morph_observed_next;
  wire [31:0] morph_observed_fixed;
  wire morph_observed_read_event;
  wire morph_observed_write_event;
  wire [31:0] morph_observed_base_compared;

  assign morph_observed_base_compared = morph_observed_base;

  ConcreteNativeAxi4SlaveFactoryFormalReferenceOffset112 concrete_dut (
    .io_axi_aw_valid(axi_aw_valid),
    .io_axi_aw_ready(concrete_aw_ready),
    .io_axi_aw_payload_addr(axi_aw_addr),
    .io_axi_aw_payload_id(axi_aw_id),
    .io_axi_aw_payload_region(axi_aw_region),
    .io_axi_aw_payload_len(axi_aw_len),
    .io_axi_aw_payload_size(axi_aw_size),
    .io_axi_aw_payload_burst(axi_aw_burst),
    .io_axi_aw_payload_lock(axi_aw_lock),
    .io_axi_aw_payload_cache(axi_aw_cache),
    .io_axi_aw_payload_qos(axi_aw_qos),
    .io_axi_aw_payload_prot(axi_aw_prot),
    .io_axi_w_valid(axi_w_valid),
    .io_axi_w_ready(concrete_w_ready),
    .io_axi_w_payload_data(axi_w_data),
    .io_axi_w_payload_strb(axi_w_strb),
    .io_axi_w_payload_last(axi_w_last),
    .io_axi_b_valid(concrete_b_valid),
    .io_axi_b_ready(axi_b_ready),
    .io_axi_b_payload_id(concrete_b_id),
    .io_axi_b_payload_resp(concrete_b_resp),
    .io_axi_ar_valid(axi_ar_valid),
    .io_axi_ar_ready(concrete_ar_ready),
    .io_axi_ar_payload_addr(axi_ar_addr),
    .io_axi_ar_payload_id(axi_ar_id),
    .io_axi_ar_payload_region(axi_ar_region),
    .io_axi_ar_payload_len(axi_ar_len),
    .io_axi_ar_payload_size(axi_ar_size),
    .io_axi_ar_payload_burst(axi_ar_burst),
    .io_axi_ar_payload_lock(axi_ar_lock),
    .io_axi_ar_payload_cache(axi_ar_cache),
    .io_axi_ar_payload_qos(axi_ar_qos),
    .io_axi_ar_payload_prot(axi_ar_prot),
    .io_axi_r_valid(concrete_r_valid),
    .io_axi_r_ready(axi_r_ready),
    .io_axi_r_payload_data(concrete_r_data),
    .io_axi_r_payload_id(concrete_r_id),
    .io_axi_r_payload_resp(concrete_r_resp),
    .io_axi_r_payload_last(concrete_r_last),
    .io_observedBase(concrete_observed_base),
    .io_observedNext(concrete_observed_next),
    .io_observedFixed(concrete_observed_fixed),
    .io_observedReadEvent(concrete_observed_read_event),
    .io_observedWriteEvent(concrete_observed_write_event),
    .clk(clk),
    .reset(reset)
  );

  MorphNativeAxi4SlaveFactoryFormalCandidateOffset112 morph_dut (
    .io_axi_aw_valid(axi_aw_valid),
    .io_axi_aw_ready(morph_aw_ready),
    .io_axi_aw_payload_addr(axi_aw_addr),
    .io_axi_aw_payload_id(axi_aw_id),
    .io_axi_aw_payload_region(axi_aw_region),
    .io_axi_aw_payload_len(axi_aw_len),
    .io_axi_aw_payload_size(axi_aw_size),
    .io_axi_aw_payload_burst(axi_aw_burst),
    .io_axi_aw_payload_lock(axi_aw_lock),
    .io_axi_aw_payload_cache(axi_aw_cache),
    .io_axi_aw_payload_qos(axi_aw_qos),
    .io_axi_aw_payload_prot(axi_aw_prot),
    .io_axi_w_valid(axi_w_valid),
    .io_axi_w_ready(morph_w_ready),
    .io_axi_w_payload_data(axi_w_data),
    .io_axi_w_payload_strb(axi_w_strb),
    .io_axi_w_payload_last(axi_w_last),
    .io_axi_b_valid(morph_b_valid),
    .io_axi_b_ready(axi_b_ready),
    .io_axi_b_payload_id(morph_b_id),
    .io_axi_b_payload_resp(morph_b_resp),
    .io_axi_ar_valid(axi_ar_valid),
    .io_axi_ar_ready(morph_ar_ready),
    .io_axi_ar_payload_addr(axi_ar_addr),
    .io_axi_ar_payload_id(axi_ar_id),
    .io_axi_ar_payload_region(axi_ar_region),
    .io_axi_ar_payload_len(axi_ar_len),
    .io_axi_ar_payload_size(axi_ar_size),
    .io_axi_ar_payload_burst(axi_ar_burst),
    .io_axi_ar_payload_lock(axi_ar_lock),
    .io_axi_ar_payload_cache(axi_ar_cache),
    .io_axi_ar_payload_qos(axi_ar_qos),
    .io_axi_ar_payload_prot(axi_ar_prot),
    .io_axi_r_valid(morph_r_valid),
    .io_axi_r_ready(axi_r_ready),
    .io_axi_r_payload_data(morph_r_data),
    .io_axi_r_payload_id(morph_r_id),
    .io_axi_r_payload_resp(morph_r_resp),
    .io_axi_r_payload_last(morph_r_last),
    .io_observedBase(morph_observed_base),
    .io_observedNext(morph_observed_next),
    .io_observedFixed(morph_observed_fixed),
    .io_observedReadEvent(morph_observed_read_event),
    .io_observedWriteEvent(morph_observed_write_event),
    .clk(clk),
    .reset(reset)
  );

  always @* begin
    if ($initstate)
      assume(reset);
    if (!$initstate) begin
      assert(concrete_aw_ready == morph_aw_ready);
      assert(concrete_w_ready == morph_w_ready);
      assert(concrete_b_valid == morph_b_valid);
      assert(concrete_ar_ready == morph_ar_ready);
      assert(concrete_r_valid == morph_r_valid);
      assert(concrete_observed_base == morph_observed_base_compared);
      assert(concrete_observed_next == morph_observed_next);
      assert(concrete_observed_fixed == morph_observed_fixed);
      assert(concrete_observed_read_event == morph_observed_read_event);
      assert(concrete_observed_write_event == morph_observed_write_event);
      if (concrete_b_valid && morph_b_valid) begin
        assert(concrete_b_id == morph_b_id);
        assert(concrete_b_resp == morph_b_resp);
      end
      if (concrete_r_valid && morph_r_valid) begin
        assert(concrete_r_data == morph_r_data);
        assert(concrete_r_id == morph_r_id);
        assert(concrete_r_resp == morph_r_resp);
        assert(concrete_r_last == morph_r_last);
      end
    end
  end
endmodule
